STACK TABLE - mod Fabric (cliente) para Minecraft 1.21.11  [NAO TESTADO]

COMO COMPILAR
1. Instale o JDK 21.
2. Va em https://fabricmc.net/develop/template e gere um projeto:
   - Minecraft 1.21.11, Mod ID: stacktable, Package: com.example.stacktable
   - NAO marque "split client and common sources"
   - Baixe e extraia o zip.
3. Apague as pastas src/main/java e src/main/resources geradas (e o arquivo
   *.mixins.json se existir) e copie para la as pastas deste projeto.
4. Na pasta do projeto: ./gradlew build   (Windows: gradlew.bat build)
5. O mod fica em build/libs/ (use o .jar SEM "-sources").
6. Coloque o jar na pasta mods junto com Fabric API, Litematica e malilib.

COMO USAR
1. Abra a lista de materiais do Litematica uma vez e feche.
2. No jogo (sem nenhuma tela aberta), aperte K (muda em Controles).
3. Role com o mouse; ESC fecha.

ZALITH (CELULAR)
- Use o Fabric Loader da 1.21.11 + Fabric API + malilib + Litematica na pasta mods da versao.
- Para abrir a tabela, digite no chat:  /tabela   (ou /stacktable)
- Na tela, use os botoes Subir / Descer / Fechar.
- Opcional: no editor de controles do Zalith, crie um botao mapeado para a tecla K.
